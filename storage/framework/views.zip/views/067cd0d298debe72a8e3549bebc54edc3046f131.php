
<?php $__env->startSection('seo_title','Ожидание оплаты'); ?>
<?php $__env->startSection('meta_keywords','Ожидание оплаты'); ?>
<?php $__env->startSection('meta_description','Ожидание оплаты'); ?>
<?php $__env->startSection('content'); ?>
    <div class="checkout-page def-page" data-ng-controller="CartController as cart">
        <div class="pre-header">
            <div class="container">
                <h1>Ожидание оплаты</h1>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="content col-12">
                    <div class="awaiting-content">
                        <div class="loader" data-ng-if="cart.loading"></div>
                        <strong>Ваш заказ № <?php echo e($orderId); ?> находится в режиме ожидания оплаты.</strong>
                        <p>Если вы произвели оплату нажмите на кнопку чтобы проверить статус.</p>
                        <a data-ng-click="cart.checkPaymentStatus(<?php echo e($orderId); ?>,<?php echo e($paymentId); ?>)" class="stsBtn">Проверить статус оплаты</a>
                        <p class="stsText">Статус: <span>{{ cart.paymentStatus }}</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/users/b/buldoorskz/domains/new.dveri-city.kz/resources/views/cart/awaiting.blade.php ENDPATH**/ ?>