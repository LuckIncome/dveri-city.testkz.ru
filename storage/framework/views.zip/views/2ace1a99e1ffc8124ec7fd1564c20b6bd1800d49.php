<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<link href="/css/slick.css" rel="stylesheet">
<link href="/css/nice-select.css" rel="stylesheet">
<link href="/css/angularjs-slider.min.css" rel="stylesheet">
<link href="/css/lightslider.min.css" rel="stylesheet">
<link href="/css/fb.css" rel="stylesheet">

<script src="/js/jquery.min.js"></script>
<script src="/js/bootstrap.bundle.min.js"></script>
<script src="/js/fb.js"></script>
<script src="/js/angular.min.js"></script>
<script src="/js/angular/angularjs-slider.min.js"></script>
<script src="/js/ui-bootstrap.js"></script>
<script src="/js/slick.js"></script>
<script src="/js/angular/app.module.js"></script>
<script src="/js/jquery.nice-select.min.js"></script>
<script src="/js/jquery.nicescroll.js"></script>
<script src="/js/lightslider.min.js"></script>

<script src="/js/script.js"></script>
<script src="/js/angular/api.service.js"></script>
<script src="/js/angular/controllers/header.controller.js"></script>
<script src="/js/angular/controllers/cart.controller.js"></script>
<script src="/js/angular/controllers/compare.controller.js"></script>
<script src="/js/angular/controllers/catalog.controller.js"></script>
<script src="/js/angular/controllers/product.controller.js"></script>
<?php /**PATH C:\xampp\htdocs\dvericity\resources\views/partials/scripts.blade.php ENDPATH**/ ?>