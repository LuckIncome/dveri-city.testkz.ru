<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js?v=23122019"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js?v=23122019"></script><![endif]-->
<link href="/css/fonts.css?v=300120202" rel="preload" as="style">
<link href="/css/fonts.css?v=300120202" rel="stylesheet">
<link href="/css/slick.css?v=300120202" rel="stylesheet">
<link href="/css/nice-select.css?v=300120202" rel="stylesheet">
<link href="/css/angularjs-slider.min.css?v=300120202" rel="stylesheet">
<link href="/css/lightslider.min.css?v=300120202" rel="stylesheet">
<link href="/css/fb.css?v=300120202" rel="stylesheet">
<link href="/css/scroll.css?v=300120202" rel="stylesheet">
<script src="/js/jquery.min.js?v=300120202"></script>
<script src="/js/bootstrap.bundle.min.js?v=300120202"></script>
<script src="/js/modernizr-custom.js?v=300120202"></script>
<script src="/js/fb.js?v=300120202"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.7.9/angular.min.js?v=300120202"></script>
<script src="/js/angular/angularjs-slider.min.js?v=300120202"></script>
<script src="/js/ui-bootstrap.js?v=300120202"></script>
<script src="/js/slick.js?v=300120202"></script>
<script src="/js/angular/app.module.js?v=300120202"></script>
<script src="/js/jquery.nice-select.min.js?v=300120202"></script>
<script src="/js/jquery.nicescroll.js?v=300120202"></script>
<script src="/js/lightslider.min.js?v=300120202"></script>
<script src="/js/script.js"></script>
<script src="/js/angular/api.service.js?v=300120202"></script>
<script src="/js/angular/controllers/header.controller.js?v=300120202"></script>
<script src="/js/angular/controllers/cart.controller.js?v=300120202"></script>
<script src="/js/angular/controllers/compare.controller.js?v=300120202"></script>
<script src="/js/angular/controllers/catalog.controller.js?v=300120202"></script>
<script src="/js/angular/controllers/product.controller.js?v=300120202"></script>
<script src="//code.jivosite.com/widget/Md7pjZc3rJ" async></script>
<a href="https://api.whatsapp.com/send?phone=+77788888848"><img src="http://new.dveri-city.kz/storage/settings/whatsapp.svg" style="position: fixed; width: 70px; height: 70px; left: 50px; bottom: 50px; z-index: 999999999;"></a><?php /**PATH /home/users/b/buldoorskz/domains/new.dveri-city.kz/resources/views/partials/scripts.blade.php ENDPATH**/ ?>