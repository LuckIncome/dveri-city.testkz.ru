<?php $__env->startSection('seo_title','404 - Такой страницы не существует'); ?>
<?php $__env->startSection('meta_keywords','404 - Такой страницы не существует'); ?>
<?php $__env->startSection('meta_description','404 - Такой страницы не существует'); ?>
<?php $__env->startSection('content'); ?>
    <div class="checkout-complete-page def-page">
        <div class="container">
            <div class="row">
                <div class="content col-12">
                    <div class="complete-content">
                        <strong>Такой страницы не существует</strong>
                        <p>Вы можете посмотреть каталог товаров перейдя по <a class="link" href="<?php echo e(route('products.index')); ?>"><span>этой ссылке</span></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dvericity\resources\views/errors/404.blade.php ENDPATH**/ ?>