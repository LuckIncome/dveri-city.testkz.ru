<!DOCTYPE HTML>
<html>
<head>
    <title>Новая заявка на Обратный звонок</title>
</head>
<body>
<h1>Новая заявка на Обратный звонок</h1>
<br>
<p>Имя отправителя : <?php echo e($name); ?></p>
<p>Телефон : <?php echo e($phone); ?></p>
</body>
</html><?php /**PATH /home/users/b/buldoorskz/domains/new.dveri-city.kz/resources/views/emails/callback.blade.php ENDPATH**/ ?>