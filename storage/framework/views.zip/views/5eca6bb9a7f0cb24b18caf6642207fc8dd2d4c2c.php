<?php $__env->startSection('seo_title','О компании'); ?>
<?php $__env->startSection('meta_keywords','О компании'); ?>
<?php $__env->startSection('meta_description','О компании'); ?>

<?php $__env->startSection('content'); ?>
    <div class="about-page def-page">
        <div class="pre-header">
            <div class="container">
                <?php echo $__env->make('partials.breadcrumbs',['title'=> 'О компании'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h1>О компании</h1>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="content col-12">
                    <div class="about-content">
                        <div class="render">
                            <h2>Входные и межкомнатные двери по оптовым ценам</h2>
                        </div>
                        <div class="text-content">
                            <p>Двери-Сити - молодая организация, которая занимается продажей входных, тамбурных и
                                межкомнатных дверей. У нас вы можете найти дверь на любой вкус, которая впишется в любой
                                дизайн интерьера.</p>
                            <p>Марка Российских металлических входных дверей "Бульдорс" известна многим. Мы являемся
                                официальным дилером этой компании в городе Алматы, что позволяет держать нам самые
                                низкие цены на этот тип дверей.</p>
                            <strong>Видео о производстве дверей</strong>
                            <div class="row">
                                <div class="col-5">
                                    <div class="video">
                                        <div class="play"></div>
                                        <img src="/images/about-video.png"
                                             alt="Входные и межкомнатные двери по оптовым ценам">
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="advantages">
                                        <div class="block col-6 d-flex flex-wrap justify-content-start">
                                            <img src="/images/pr1-black.svg" alt="Гарантия качества">
                                            <div class="text">
                                                <h4>Гарантия качества</h4>
                                                <p>Предприятие оснащено самым новейшим высокоточным оборудованием, что
                                                    позволяет избежать погрешностей и дефектов. Вся наша продукция
                                                    сертифицированная и имеет гарантии.</p>
                                            </div>
                                        </div>
                                        <div class="block col-6 d-flex flex-wrap justify-content-start">
                                            <img src="/images/pr2-black.svg" alt="Гарантия качества">
                                            <div class="text">
                                                <h4>Экологичность</h4>
                                                <p>Исключительно все модели: от экономичных до дорогостоящих, сделаны из
                                                    материалов, отличающихся экологической безопасностью и высокой
                                                    износостойкостью, в строгом соответствии со всеми стандартами
                                                    качества.</p>
                                            </div>
                                        </div>
                                        <div class="block col-6 d-flex flex-wrap justify-content-start">
                                            <img src="/images/pr2-black.svg" alt="Гарантия качества">
                                            <div class="text">
                                                <h4>Широкий ассортимент</h4>
                                                <p>В ассортименте представлено более 10-ти товарных групп! Это выгодно
                                                    для
                                                    тех клиентов, у которых представлен широкий ассортимент продукции,
                                                    так
                                                    как им не нужно «собирать» свой ассортимент по частям от разных
                                                    поставщиков.</p>
                                            </div>
                                        </div>
                                        <div class="block col-6 d-flex flex-wrap justify-content-start">
                                            <img src="/images/pr4-black.svg" alt="Гарантия качества">
                                            <div class="text">
                                                <h4>Доверие</h4>
                                                <p>Компания «DveriCity» предлагает богатое разнообразие моделей и
                                                    широкий
                                                    диапазон цен, исходя из запросов наших покупателей. Каждый заказ
                                                    максимально прорабатывается с учетом всех пожеланий клиента.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="bottom-block">
                                <div class="text col-6">
                                    <p>Двери-Сити - молодая организация, которая занимается продажей входных, тамбурных
                                        и межкомнатных дверей. У нас вы можете найти дверь на любой вкус, которая
                                        впишется в любой дизайн интерьера.</p>
                                    <p>Марка Российских металлических входных дверей
                                        "Бульдорс" известна многим. Мы являемся официальным дилером этой компании в
                                        городе Алматы, что позволяет держать нам самые низкие цены на этот тип
                                        дверей.</p>
                                    <p>С
                                        другой стороны, постоянный количественный рост и сфера нашей активности является
                                        качественно новой ступенью как самодостаточных, так и внешне зависимых
                                        концептуальных решений!</p>
                                </div>
                                <div class="slider col-6">
                                    <div class="sliderContent">
                                        <div class="item">
                                            <img src="/images/about-slider.png" alt="">
                                        </div>
                                        <div class="item">
                                            <img src="/images/about-slider.png" alt="">
                                        </div>
                                        <div class="item">
                                            <img src="/images/about-slider.png" alt="">
                                        </div>
                                        <div class="item">
                                            <img src="/images/about-slider.png" alt="">
                                        </div>
                                    </div>
                                    <div class="sliderArrows">
                                        <a class="prevSlide">Previous</a>
                                        <span>1/10</span>
                                        <a class="nextSlide">Next</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('partials.modalVideo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dvericity\resources\views/pages/about.blade.php ENDPATH**/ ?>