<div id="modalVideo" class="modal">
    <!-- Modal content -->
    <div class="modal-content popup-video">
                <iframe data-allowfullscreen="true" data-allowscriptaccess="always"
                        src="https://www.youtube.com/embed/-K_sDC6FuSg?version=3&autoplay=1&enablejsapi=1">
                </iframe>
    </div>
</div><?php /**PATH C:\xampp\htdocs\dvericity\resources\views/partials/modalVideo.blade.php ENDPATH**/ ?>