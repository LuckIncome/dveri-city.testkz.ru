<?php $__env->startSection('seo_title','Сравнение товаров'); ?>
<?php $__env->startSection('meta_keywords','Сравнение товаров'); ?>
<?php $__env->startSection('meta_description','Сравнение товаров'); ?>
<?php $__env->startSection('content'); ?>
    <div class="compare-page def-page" data-ng-controller="CompareController as comp">
        <div class="pre-header">
            <div class="container">
                <h1>Сравнение товаров</h1>
            </div>
        </div>
        <div class="container" data-ng-init="comp.init()">
            <div class="row">
                <div class="content col-12">
                    <div class="compare-content">
                        <div class="header-btns">
                            <div class="btns col-4">
                                <a href="<?php echo e(route('products.index')); ?>" class="back">Вернуться</a>
                                <a class="clear" data-ng-click="comp.clearCompare()" data-ng-if="comp.itemsCount > 0">Очистить
                                    список</a>
                            </div>
                            <div class="filter col-4" data-ng-if="comp.showDiffBtn">
                                <div class="custom-control custom-radio">
                                    <input data-ng-model="comp.charsBtn" data-ng-change='comp.charsSelect(comp.charsBtn)' type="radio" class="custom-control-input" id="charAll"
                                           name="characteristics" value="all" checked>
                                    <label class="custom-control-label" for="charAll">Все характеристики</label>
                                </div>
                                <div class="custom-control custom-radio">
                                    <input data-ng-model="comp.charsBtn" data-ng-change='comp.charsSelect(comp.charsBtn)' type="radio" class="custom-control-input" id="charDiffs"
                                           name="characteristics" value="difference">
                                    <label class="custom-control-label" for="charDiffs">Только различия</label>
                                </div>
                            </div>
                        </div>
                        <div class="products">
                            <div class="col-3" data-ng-repeat="product in comp.products">
                                <div class="item">
                                    <div class="image" style="background: url(../images/image1.png) center no-repeat;">
                                        <span data-ng-if="product.attributes.is_new" data-ng-class="product.attributes.is_new ? 'new flash' : 'flash'">Новинка</span>
                                        <span data-ng-if="product.attributes.regular_price && !product.attributes.is_new"
                                              data-ng-class="product.attributes.is_new ? 'sale flash' : 'flash'">Акция</span>

                                        <span class="flash remove" data-ng-click="comp.deleteItem(product)">&times;</span>
                                        <a data-ng-href="{{ product.attributes.link }}">
                                            <img data-ng-src="{{ product.attributes.image_link }}" src="#"
                                                 alt="{{ product.attributes.name }}">
                                        </a>
                                    </div>
                                    <div class="text">
                                        <a data-ng-href="{{ product.attributes.link }}" class="name">{{
                                            product.attributes.name }}</a>
                                        <hr>
                                        <span class="priceLabel">Цена:</span>
                                        <div class="price" data-ng-if="product.attributes.regular_price">
                                            <p class="old-price"
                                               data-ng-if="product.attributes.regular_price">{{ product.attributes.regular_price }} <span
                                                        class="valute">₸</span></p>
                                            <p class="new-price">{{ product.price }} <span class="valute">₸</span></p>
                                        </div>
                                    </div>
                                    <div class="btns">
                                        <a class="add-to-cart" data-ng-click="comp.addToCart(product)" data-ng-if="product.attributes.stock_count && !product.inCart">Купить</a>
                                        <a href="<?php echo e(route('cart.index')); ?>" class="add-to-cart" data-ng-if="product.attributes.stock_count && product.inCart">В корзину</a>
                                        <p class="out-of-stock" data-ng-if="!product.attributes.stock_count">Нет в наличии</p>
                                        <a class="add-to-compare active" data-ng-click="comp.deleteItem(product)"></a>
                                    </div>
                                </div>
                                <div class="item-chars">
                                    <div class="char" data-ng-repeat="char in product.characteristics">
                                        <strong>{{ char.name }}:</strong>
                                        <p>{{ char.value }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dvericity\resources\views/products/compare.blade.php ENDPATH**/ ?>