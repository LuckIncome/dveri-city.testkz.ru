<?php $__env->startSection('seo_title','Новости'); ?>
<?php $__env->startSection('content'); ?>
    <div class="sales-page def-page">
        <div class="pre-header">
            <div class="container">
                <?php echo $__env->make('partials.breadcrumbs',['title'=> 'Новости'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h1>Новости</h1>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="content col-12">
                    <div class="sales">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="sale-block">
                                <div class="image col-5">
                                    <img src="<?php echo e(Voyager::image($post->image)); ?>" alt="<?php echo e($post->title); ?>">
                                </div>
                                <div class="info col-7">
                                    <a class="title" href="<?php echo e(route('posts.show',$post->slug)); ?>"><?php echo e($post->title); ?></a>
                                    <p class="text"><?php echo e($post->excerpt); ?></p>
                                    <span class="date"><?php echo e(Carbon\Carbon::parse($post->created_at)->format('d.m.Y')); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dvericity\resources\views/posts/index.blade.php ENDPATH**/ ?>