
<?php $__env->startSection('seo_title','Оформление заказа'); ?>
<?php $__env->startSection('meta_keywords','Оформление заказа'); ?>
<?php $__env->startSection('meta_description','Оформление заказа'); ?>
<?php $__env->startSection('content'); ?>
    <div class="checkout-complete-page def-page" data-ng-controller="CartController as cart">
        <div class="pre-header">
            <div class="container">
                <h1>Завершение</h1>
            </div>
        </div>
        <div class="container" data-ng-init="cc.init()">
            <div class="row">
                <div class="content col-12">
                    <div class="complete-content">
                        <strong>Спасибо, ваш заказ № <?php echo e($order->id); ?> принят и уже обрабатывается.</strong>
                        <p>Мы с вами свяжемся в ближайшее рабочее время для уточнения деталей.</p>
                    </div>
                    <div class="cart-bottom">
                        <div class="row">
                            <div class="next col-3">
                                <a href="<?php echo e(route('products.index')); ?>">Продолжить покупки</a>
                            </div>
                            <div class="steps col-6 offset-3">
                                <ul>
                                    <li>Корзина</li>
                                    <li class="arrow"><span class="fa fa-angle-right"></span></li>
                                    <li>Оформление заказа</li>
                                    <li class="arrow"><span class="fa fa-angle-right"></span></li>
                                    <li class="active">Завершение</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/users/b/buldoorskz/domains/new.dveri-city.kz/resources/views/cart/thanks.blade.php ENDPATH**/ ?>