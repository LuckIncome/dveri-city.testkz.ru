<?php $__env->startSection('seo_title','Акции и Скидки'); ?>
<?php $__env->startSection('content'); ?>
    <div class="sales-page def-page">
        <div class="pre-header">
            <div class="container">
                <?php echo $__env->make('partials.breadcrumbs',['title'=> 'Акции'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h1>Акции</h1>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="content col-12">
                    <div class="sales">
                        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="sale-block">
                                <div class="image col-5">
                                    <img src="<?php echo e(Voyager::image($sale->image)); ?>" alt="<?php echo e($sale->title); ?>">
                                </div>
                                <div class="info col-7">
                                    <a href="<?php echo e(route('sales.show',$sale->slug)); ?>"><strong class="title"><?php echo e($sale->title); ?></strong></a>
                                    <p class="text"><?php echo e($sale->excerpt); ?></p>
                                    <span class="date"><?php echo e(Carbon\Carbon::parse($sale->created_at)->format('d.m.Y')); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dvericity\resources\views/sales/index.blade.php ENDPATH**/ ?>