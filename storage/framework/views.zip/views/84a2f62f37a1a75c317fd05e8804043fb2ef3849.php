<div class="popup popup-thank-you">
    <div class="popup-wrapper">
        <div class="popup-order-call-img">
            <div class="img">
                <img src="/images/slide.png" alt="Заказать обратный звонок">
            </div>
        </div>
        <div class="container">
            <div class="popup-order-call-right">
                <div class="popup-thank-you-heading">
                    Спасибо за заявку!
                </div>
                <div class="popup-thank-you-sub-heading">
                    Вас автоматически перенесет на главную страницу через 3 секунды
                </div>
                <a class="popup-thank-you-home-btn" href="#">На главную</a>
            </div>
        </div>
        <div class="close-popup">
            <svg width="25" height="18" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1 1L16.5 16.5" stroke="#989898"/>
                <path d="M16.5 1L1 16.5" stroke="#989898"/>
            </svg>

        </div>
    </div>
</div>
<div class="popup popup-order-call">
    <div class="popup-wrapper">
        <div class="popup-order-call-img">
            <div class="img">
                <img src="/images/slide.png" alt="Заказать обратный звонок">
            </div>
        </div>
        <div class="container">
            <div class="popup-order-call-right">
                <div class="popup-order-call-heading">
                    <span>Закажите звонок</span> и мы ответим в кратчайшие сроки
                </div>
                <div class="popup-order-call-form">
                    <form>
                        <?php echo e(csrf_field()); ?>

                        <label>
                            <span>Введите ваше имя *</span>
                            <input type="text" name="name" placeholder="Иван Иванович" required>
                        </label>
                        <label>
                            <span>Введите ваш телефон *</span>
                            <input type="tel" name="phone" placeholder="+7 ( ___ ) ___ - __ - __" required>
                        </label>
                        <input type="submit" class="btn-orange" value="Отправить заявку">
                    </form>
                </div>
            </div>
        </div>
        <div class="close-popup">
            <svg width="25" height="18" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1 1L16.5 16.5" stroke="#989898"/>
                <path d="M16.5 1L1 16.5" stroke="#989898"/>
            </svg>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\dvericity\resources\views/partials/modals.blade.php ENDPATH**/ ?>